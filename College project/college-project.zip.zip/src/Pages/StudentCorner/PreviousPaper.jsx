import React from 'react';
import '../Detail.css';


const previouspaper = () => {
  return (
    <div className="detail-container">
      <div className="detail-content">
        <h2>PREVIOUS PAPERS</h2>

        <p>
        Here's the section which consists of the previous year papers as per the Branch wise on our site.</p>
      </div>
      <div className="detail-image">
        <img src="/images/menu_oldpaper.jpg" alt="History" />
      </div>
    </div>
  );
};

export default previouspaper;