import React from 'react';
import '../Detail.css';

const Exams = () => {
  return (
    <div className="detail-container">
      <div className="detail-content">
        <h2>EXAMS</h2>
        
<p>
desktop
To view the detail Regarding exams click the link provided below.
</p>
      </div>
      <div className="detail-image">
        <img src="/images/menu_exams.jpg "alt="History" />
      </div>
    </div>
  );
};

export default Exams;