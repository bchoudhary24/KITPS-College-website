/*import React from 'react';
import '../Detail.css';


const Alumni = () => {
  return (
    <div className="detail-container">
      <div className="detail-content">
        <h2>ALUMNI</h2>
<p>
It comprise of Ex. Students of KITPS. The association involves in active alumni interactions and enhance image of Kothiwal institute of technology and professional studies through self enrichment, career development and role modeling in the wider society.
</p>
      </div>
      <div className="detail-image">
        <img src="/images/menu_ Alumni.jpg"alt="Alumni" />
      </div>
    </div>
  );
};

export default Alumni;*/
import React from 'react';

const Alumni = () => {
  return (
    <div style={{ padding: '50px', textAlign: 'center' }}>
      <h1 style={{ color: 'red' }}>✅ Alumni Page Loaded!</h1>
    </div>
  );
};

export default Alumni;