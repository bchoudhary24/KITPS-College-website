import React from 'react';
import '../Detail.css';


const AcademicCalender = () => {
  return (
    <div className="detail-container">
      <div className="detail-content">
        <h2>ACADEMIC CALENDER</h2>
        
      <p>  The official academic calendar of the University of AKTU.To view academic calendar click on view morep
      </p>
      </div>
      <div className="detail-image">
        <img src="/images/menu_acdcalener.jpg" alt="Academiccalender" />
      </div>
    </div>
  );
};

export default AcademicCalender;