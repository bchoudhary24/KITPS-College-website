function AntiRagging() {
    return <div>
        
        <h2>Anti-ragging</h2></div>;
  }
  export default AntiRagging