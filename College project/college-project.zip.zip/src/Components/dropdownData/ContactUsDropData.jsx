const contactItems = [
    {
      title: "Contact Information",
      content:`Please feel free to contact us if you need any further information. Please let us know if you have any questionsKothiwal Institute of Technology & Professional Studies,Pachokra, Haridwar Road"</P>
      Moradabad - 244 001 (U.P.) INDIA
     Phone +91-0591-2479700, 2479707, 9897868221
     Email: kitps_mbd@kothiwalinstitutetechnology.com.`,
    image: "/images/menu_condetail.jpg",
      link: "/contact-info",
    },
    {
      title: "HOW TO REACH",
      content: "KITPS is located at about 17 km. from railways / bus-station on Moradabad-Haridwar Road.",
      image: "/images/menu_reachmap.jpg",
      link: "/HOW TO REACH",
    },
  ];
  
  export default contactItems;